import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ticketmaster } from '../models/ticketmaster.interface';

@Injectable({
  providedIn: 'root'
})
export class TicketmasterService {
  public apiKey: string = "tZ08mVmIlAuo2fAnahB2eYN5ThiLLaQY";

  constructor(public http: HttpClient) { }

  public getResponse(): Observable<Ticketmaster> {
    return this.http.get<Ticketmaster>('https://app.ticketmaster.com/discovery/v2/events?countryCode=ES&apikey=tZ08mVmIlAuo2fAnahB2eYN5ThiLLaQY');
  }
    
}
