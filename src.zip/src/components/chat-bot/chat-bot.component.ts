import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import AOS from 'aos';

@Component({
  selector: 'app-chat-bot',
  imports: [CommonModule],
  templateUrl: './chat-bot.component.html',
  styleUrl: './chat-bot.component.css'
})
export class ChatBotComponent {
  public isOpen:boolean = false;

  toggleChat() {
    this.isOpen = !this.isOpen;
  }

  ngOnInit(): void {
      AOS.init();
  }
}
