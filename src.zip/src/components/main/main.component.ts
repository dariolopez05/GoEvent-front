import { Component } from '@angular/core';
import { TicketmasterService } from '../../services/ticketmaster.service';

@Component({
  selector: 'app-main',
  imports: [],
  standalone: true,
  templateUrl: './main.component.html',
  styleUrl: './main.component.css'
})
export class MainComponent {
  public constructor(public service: TicketmasterService) {}

  public topEvents: any[] = []; //Sin el any no puedo guardar toda la info del evento

  public getResponse(): void {
    this.service.getResponse().subscribe((response) => {
      const events = response._embedded.events;

      for (let i = 0; i < Math.min(6, events.length); i++) {
        this.topEvents.push(events[i]); 
      }

      console.log(this.topEvents);
    });
  }

  public ngOnInit(): void {
    this.getResponse();
  }
}

